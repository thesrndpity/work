/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./wsioAutoSuggest/src/index.ts":
/*!**************************************!*\
  !*** ./wsioAutoSuggest/src/index.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\n/// <reference types=\"powerapps-component-framework\" />\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.wsioAutoSuggest = void 0;\nvar wsioAutoSuggest = /** @class */function () {\n  // Constructor with initialization logic moved to property declarations\n  function wsioAutoSuggest() {\n    // Initialize all properties with default values\n    this._value = \"\"; // Initialize _value as an empty string\n    this._table = \"\"; // Initialize _table as an empty string\n    this._column = \"\"; // Initialize _column as an empty string\n    this._notifyOutputChanged = function () {}; // Initialize with a default empty function\n    this.inputElement = document.createElement(\"input\"); // Create input element directly\n    this.datalistElement = document.createElement(\"datalist\"); // Create datalist element directly\n    this._container = document.createElement(\"div\"); // Create container element directly\n    this._refreshData = this.refreshData.bind(this); // Bind refreshData to this\n  }\n  // Initialize the control\n  wsioAutoSuggest.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _this = this;\n    // Assign context and notifyOutputChanged\n    this._context = context;\n    this._table = this._context.parameters.wsioTable.raw;\n    this._column = this._context.parameters.wsioColumn.raw;\n    this._notifyOutputChanged = notifyOutputChanged;\n    // Set up the input element\n    this.inputElement.setAttribute(\"list\", \"list-\".concat(this._table));\n    this.inputElement.setAttribute(\"name\", \"autosuggest-\".concat(this._table));\n    this.inputElement.setAttribute(\"type\", \"text\");\n    this.inputElement.setAttribute(\"class\", \"wsio-input\");\n    this.inputElement.addEventListener(\"input\", this._refreshData);\n    // Set up the datalist element\n    this.datalistElement.setAttribute(\"id\", \"list-\".concat(this._table));\n    this.datalistElement.innerHTML = \"\";\n    // Append elements to the container\n    this._container.appendChild(this.datalistElement);\n    this._container.appendChild(this.inputElement);\n    container.appendChild(this._container);\n    // Fetch data for options\n    var optionsHTML = \"\";\n    var optionsHTMLarr = [];\n    var _webApi = context.webAPI;\n    try {\n      _webApi.retrieveMultipleRecords(this._table, \"?$select=\".concat(this._column)).then(function (_a) {\n        var _b;\n        var entities = _a.entities,\n          nextLink = _a.nextLink;\n        if (nextLink) console.warn(\"WSIO PCF:\", \"More records available: \".concat(nextLink));\n        if (entities) {\n          for (var i = 0; i < entities.length; ++i) {\n            optionsHTMLarr.push('<option value=\"');\n            optionsHTMLarr.push(((_b = entities[i][_this._column]) === null || _b === void 0 ? void 0 : _b.toString()) || \"\");\n            optionsHTMLarr.push('\" />');\n          }\n          optionsHTML = optionsHTMLarr.join(\"\");\n        }\n        _this.datalistElement.innerHTML = optionsHTML;\n      }, function (err) {\n        if (err instanceof Error) console.error(err);\n      });\n    } catch (err) {\n      if (err instanceof Error) console.error(err);\n    }\n  };\n  // Handle input data refresh\n  wsioAutoSuggest.prototype.refreshData = function (evt) {\n    this._value = this.inputElement.value;\n    this._notifyOutputChanged();\n  };\n  // Update view if needed\n  wsioAutoSuggest.prototype.updateView = function (context) {};\n  // Return outputs when required\n  wsioAutoSuggest.prototype.getOutputs = function () {\n    return {\n      selectedValue: this._value\n    };\n  };\n  // Cleanup on destroy\n  wsioAutoSuggest.prototype.destroy = function () {\n    this.inputElement.removeEventListener(\"input\", this._refreshData);\n  };\n  return wsioAutoSuggest;\n}();\nexports.wsioAutoSuggest = wsioAutoSuggest;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./wsioAutoSuggest/src/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./wsioAutoSuggest/src/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('PCFControls.wsioAutoSuggest', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.wsioAutoSuggest);
} else {
	var PCFControls = PCFControls || {};
	PCFControls.wsioAutoSuggest = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.wsioAutoSuggest;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}